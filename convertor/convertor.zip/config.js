gStoCfg = {"priceFile":"C:\\Project\\Code\\SelfCreatedTool\\stock\\"}
gTradePerPage=5;
gStoTrade=[
{name:'lchina', action:'sell', shareNo:500, price:15.4, broker:'ocbcus', date:'2008-07-09', rate:'1.36', currency:'usd' },
{name:'lchina', action:'buy', shareNo:500, price:14.4, broker:'ocbcus', date:'2008-07-03', rate:'1.36', currency:'usd' },
{name:'lcmmdy', action:'buy', shareNo:1500, price:3.77, broker:'ocbcus', date:'2008-08-11', rate:'1.4', currency:'usd' },
{name:'lcmmdy', action:'buy', shareNo:1500, price:4.09, broker:'ocbcus', date:'2008-07-23', rate:'1.4', currency:'usd' },
{name:'lcmmdy', action:'sell', shareNo:1200, price:4.05, broker:'ocbcus', date:'2008-02-29', rate:'1.36', currency:'usd' },
{name:'lcmmdy', action:'buy', shareNo:1200, price:3.57, broker:'ocbcus', date:'2008-01-15', rate:'1.36', currency:'usd' },
{name:'qianhu', action:'buy', shareNo:26000, price:0.178, broker:'ocbc', date:'2008-01-15', rate:'1', currency:'sgd' },
{name:'stietf', action:'buy', shareNo:2000, price:2.83, broker:'ocbc', date:'2008-08-13', rate:'1', currency:'sgd' },
{name:'stietf', action:'buy', shareNo:2000, price:2.98, broker:'ocbc', date:'2008-03-10', rate:'1', currency:'sgd' },
{name:'stietf', action:'buy', shareNo:2000, price:3.38, broker:'ocbc', date:'2008-01-15', rate:'1', currency:'sgd' },
{name:'stietf', action:'buy', shareNo:2000, price:2.99, broker:'ocbc', date:'2008-07-03', rate:'1', currency:'sgd' },
{name:'stietf', action:'buy', shareNo:1000, price:3.05, broker:'ocbc', date:'2008-02-11', rate:'1', currency:'sgd' }
];
