[

{name:'stietf', action:'buy', shareNo:2000, price:3.05, broker:'ocbc', date:'05Mar2008' },
{name:'stietf', action:'buy', shareNo:1500, price:2.85, broker:'ocbc', date:'08Aug2008' },
{name:'stietf', action:'sell', shareNo:1000, price:3.3, broker:'ocbc', date:'08Aug2008' },
{name:'stietf', action:'buy', shareNo:243, price:3.6, broker:'ocbc', date:'' }
]