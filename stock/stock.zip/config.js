[
/*{
    name: "SENSEX",
    group: "India,Index",
    url: "http://www.bseindia.com/mktlive/mktwatch.asp",
    title: "Time\t\tIndex\t\tChange\t\tPercent\t\tLow\t\tHigh",
    attrs: ["open", "high","low","index","yesterday", "change", "percent"],
    getStockData: function(str)
                 {
						var re=minMatch(str, /<tr>.*SENSEX.*><\/tr>/i);
						re = re[0].match(/.*>(.+)<\/font>.*>(.+)<\/font>.*>(.+)<\/font>.*>(.+)<\/font>.*>(.+)<\/font>.*>(.+)<\/font>.*>(.+)<\/font>/i)
						return re;
			      },
    priceBoard: function(curObj, lastObj)
                {
                     var last = lastObj? lastObj.index:"-";
                     var re = ["SENSEX"];
    		     var tmp = String.format("%s/%s", curObj.index, last);
    		     re.push(tmp);
    		     re.push("");
    		     re.push(curObj.change);
    		     re.push((new Date()).format("HH:MM:ss"));
    		     return re;
    		 },
    logStr: function(obj){return String.format("[%s] \t%s  \t%s\t\t%s\t\t%s  \t%s", (new Date()).format("HH:MM:ss"), obj.index, obj.change,
                                                obj.percent, obj.low, obj.high);},
    yahooSymbol: "^BSESN",
    compareAttr: "index"
    //upPriceAlert: "3.08",
    //downPriceAlert: "3.05"
},*/
{
    name: "Lyxor India",
    group: "ETF,India",
    upPriceAlert: "15.2",
    downPriceAlert: "11.0",
    yahooSymbol: "FC6.SI"
},
{
    name: "Singtel",
    group: "Telco",
    upPriceAlert: "3.85",
    downPriceAlert: "2.95",
    yahooSymbol: "Z74.SI"
},
{
    name: "SHI",
    group: "China,Index",
    url: "http://www.sse.com.cn/sseportal/ps/zhs/hqjt/zs.jsp",
    pattern: new RegExp("<tr[\\s\\S]*>"+String.fromCharCode(19978,35777,25351, 25968)+"<[\\s\\S]*>(.*)<\\/td[\\s\\S]*>(.*)<\\/td[\\s\\S]*\\/tr", "i"),
    title: "Time\t\tIndex\t\tChange",
    attrs: ["index", "change"],
    priceBoard: function(curObj, lastObj)
                {
                     var last = lastObj? lastObj.index:"-";
                     var re = ["SHI"];
    		     var tmp = String.format("%s/%s", curObj.index, last);
    		     re.push(tmp);
    		     re.push("");
    		     re.push(curObj.change);
    		     re.push((new Date()).format("HH:MM:ss"));
    		     return re;
    		 },
    logStr: function(obj){return String.format("[%s] \t%s\t\t%s", (new Date()).format("HH:MM:ss"), obj.index, obj.change);},
    compareAttr: "index",
    upPriceAlert: "3100",
    downPriceAlert: "2050",
    yahooSymbol: "000001.SS"
},

{
    name: "STI",
    group: "Index",
    url: "http://www.sgx.com",
    pattern: /<tr>[\s\S]*ST Index[\s\S]*>(.+)&nbsp;(.+)<\/div>[\s\S]*<\/tr>/i,
    title: "Time\t\tIndex\t\tChange",
    attrs: ["index", "change"],
    priceBoard: function(curObj, lastObj)
                {
                     var last = lastObj? lastObj.index:"-";
                     var re = ["STI"];
    		     var tmp = String.format("%s/%s", curObj.index, last);
    		     re.push(tmp);
    		     re.push("");
    		     re.push(curObj.change);
    		     re.push((new Date()).format("HH:MM:ss"));
    		     return re;
    		 },
    logStr: function(obj){return String.format("[%s] \t%s\t\t%s", (new Date()).format("HH:MM:ss"), obj.index, obj.change);},
    compareAttr: "index",
    upPriceAlert: "3200",
    downPriceAlert: "2150",
    yahooSymbol: "^STI"
},
{
    name: "Gold",
    group: "Commodities",
    url: "http://www.sgx.com",
    pattern: />Gold Spot Price.*>(.*)<\/div>/i,
    title: "Time\t\tPrice",
    attrs: ["price"],
    priceBoard: function(curObj, lastObj)
                {
                     var last = lastObj? lastObj.price:"-";
                     var re = ["Gold"];
    		     var tmp = String.format("%s/%s", curObj.price, last);
    		     re.push(tmp);
    		     re.push("");
    		     re.push("");
    		     re.push((new Date()).format("HH:MM:ss"));
    		     return re;
    		 },
    logStr: function(obj){return String.format("[%s] \t%s", (new Date()).format("HH:MM:ss"), obj.price);},
    compareAttr: "price",
    upPriceAlert: "980",
    downPriceAlert: "750"
},
{
    name: "STI ETF",
    yahooSymbol: "ES3.SI",
    upPriceAlert: "3.25",
    downPriceAlert: "2.40",
    group: "Portfolio,ETF"
},
{
    name: "QianHu",
    upPriceAlert: "0.175",
    downPriceAlert: "0.10",
    yahooSymbol: "552.SI",
   	group: "Portfolio"
},
{
    name: "Capitaland",
    yahooSymbol: "C31.SI",
    group: "Estate",
    upPriceAlert: "5.5",
    downPriceAlert: "2.85"
},
{
    name: "CapitaMall",
    yahooSymbol: "C38U.SI",
    group: "Commerce",
    upPriceAlert: "3",
    downPriceAlert: "1.85"
},
{
    name: "ChinaEnergy",
    yahooSymbol: "A0G.SI",
    group: "China,Commodities"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "China Fish",
    yahooSymbol: "B0Z.SI",
    group: "China"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "ChinaMilk",
    yahooSymbol: "G86.SI",
    group: "China"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "ChinaOilFld",
    yahooSymbol: "DT2.SI",
    group: "China,Commodities"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "CITYDEV",
    yahooSymbol: "C09.SI",
    group: "Estate",
    //upPriceAlert: "12",
    downPriceAlert: "7"
},
{
    name: "GreatEast",
    yahooSymbol: "G07.SI",
    group: "Finance"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "SuntecReit",
    yahooSymbol: "T82U.SI",
    group: "Estate"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},

{
    name: "Lyxor China",
    group: "China,ETF",
	yahooSymbol: "P58.SI",
    upPriceAlert: "17.5",
    downPriceAlert: "11.1"
},
{
    name: "Lyxor Cmdty",
    group: "Commodities,ETF,Portfolio",
	yahooSymbol: "A0W.SI",
    upPriceAlert: "4.8",
    downPriceAlert: "2.60"
},
{
    name: "Kep Corp"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "KepLand",
	yahooSymbol: "K17.SI",
    group: "Estate"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "M1",
	yahooSymbol: "B2F.SI",
    group: "Telco"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "Starhub",
	yahooSymbol: "CC3.SI",
    group: "Telco"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "UOB",
	yahooSymbol: "U11.SI",
    group: "Finance",
    upPriceAlert: "21.5",
    downPriceAlert: "16.0"
},
{
    name: "OCBC Bk",
	yahooSymbol: "O39.SI",
    group: "Finance"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
},
{
    name: "DBS",
	yahooSymbol: "D05.SI",
    group: "Finance",
    upPriceAlert: "22.0",
    downPriceAlert: "16.15"
},

{
    name: "SPH"
    //upPriceAlert: "1",
    //downPriceAlert: "0.8"
}
]